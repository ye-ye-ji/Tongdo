$(function(){
    var gnb = $("#gnb > li"),
        gnbBg = $(".gnbwrap  #gnb > li > .gnbBg"),
        srchBtn = $("#header .search"),
        closBt = $("#header .closeBtn"),
        member = $("#header nav .gnbRight p.member"); 

    gnb.mouseenter(function(){
        gnbBg.stop().slideDown();
    });

    gnb.mouseleave(function(){
        gnbBg.stop().slideUp();
    });

    srchBtn.click(function(){
        $(".srchArea").slideDown(400);
    });
    closBt.click(function(){
        $(".srchArea").slideUp(400);
    });

    member.mouseenter(function(){
        $(this).children(".memberJoin").stop().slideDown();
    });

    member.mouseleave(function(){
        $(this).children(".memberJoin").stop().slideUp();
    });

    var mainVisual = new Swiper('.section .main_visual .swiper-container', {
        centeredSlides: true,
        autoplay: {
          delay: 3500,
          disableOnInteraction: false,
        },
        loop:true,
        pagination: {
          el: '.main_visual .swiper-pagination',
          clickable: true,
        },
        navigation: {
          nextEl: '.main_visual .swiper-button-next',
          prevEl: '.main_visual .swiper-button-prev',
        },
    });

    var sec1Swiper = new Swiper('.main_con1 .swiper-container', {
        slidesPerView: 3,
        direction: getDirection(),
        loop:true,
        navigation: {
          nextEl: '.main_con1 .swiper-button-next',
          prevEl: '.main_con1 .swiper-button-prev',
        },
        on: {
          resize: function () {
            swiper.changeDirection(getDirection());
          }
        }
    });
      
    function getDirection() {
        var windowWidth = window.innerWidth;
        var direction = window.innerWidth <= 760 ? 'vertical' : 'horizontal';
        return direction;
        }

    var $mainTit = $('.main_sec2 .main_tit h2'),
        $night = $('.main_sec2 .main_tit h2.night'),
        $child = $('.main_sec2 .main_tit h2.child');

    let $tabMenu = $('.main_sec2 .tab_btn p'),
        $tabnight = $('.main_sec2 .tab_btn p.night'),
        $tabchild = $('.main_sec2 .tab_btn p.child'),
        $tabCon = $('.main_sec2 .main_con2 .list');

        $tabMenu.on('click',function(e){
            e.preventDefault(); 

            let _href = $(this).children('a').attr('href');
            $tabCon.hide();
            $( _href ).show();
            
            $tabMenu.removeClass('on');
            $(this).addClass('on');

            $mainTit.hide();
            if($tabnight.hasClass('on')){
                $night.show();
            }else if($tabchild.hasClass('on')){
                $child.show();
            }
    });

    var sec4Swiper = new Swiper('.main_sec4 .swiper-container', {
        slidesPerView: 4,
        spaceBetween: 30,
        loop:false,
        pagination: {
          el: '.main_sec4 .swiper-btWrap .swiper-pagination',
          clickable: true,
        },
        navigation: {
            nextEl: '.main_sec4 .swiper-btWrap .swiper-button-next',
            prevEl: '.main_sec4 .swiper-btWrap .swiper-button-prev',
        },
    });

    $(function(){
        $('#newsticker2').Vnewsticker({
          speed: 700,         
          pause: 2500,       
          mousePause: true,  
          showItems: 1,    
          direction : "Up" 
        });
    });

    (function (a)
    {a.fn.Vnewsticker = function (b)
        {var c = {
            speed : 700, 
            pause : 2500, 
            showItems : 1, 
            mousePause : true, 
            isPaused : false, 
            direction : "Up", 
            width : 0
            };
            var b = a.extend(c, b);
            moveSlide = function (g, d, e)
            { if (e.isPaused) {
                    return
                }
                var f = g.children("ul");
                var h = f.children("li:first").clone(true);
                if (e.width > 0) {
                    d = f.children("li:first").width()
                }
                f.animate({
                    left : "-=" + d + "px"
                },
                e.speed, function (){
                    a(this).children("li:first").remove();
                    a(this).css("left", "0px")
                });
                h.appendTo(f)
            };
            moveUp = function (g, d, e)
            { if (e.isPaused) {
                    return
                }
                var f = g.children("ul");
                var h = f.children("li:first").clone(true);
                if (e.height > 0) {
                    d = f.children("li:first").height()
                }
                f.animate({
                    top : "-=" + d + "px"
                },
                e.speed, function (){
                    a(this).children("li:first").remove();
                    a(this).css("top", "0px")
                });
                h.appendTo(f)
            };
            moveDown = function (g, d, e)
            {if (e.isPaused) {
                    return
                }
                var f = g.children("ul");
                var h = f.children("li:last").clone(true);
                if (e.height > 0) {
                    d = f.children("li:first").height()
                }
                f.css("top", "-" + d + "px").prepend(h);
                f.animate({
                    top : 0
                },
                e.speed, function (){
                    a(this).children("li:last").remove()
                });
            };
            return this.each(function (){
                var f = a(this);
                var e = 0;
                var u = f.children("ul");
                var l = u.children("li").length;
                var w = u.children("li").width();
                var ulw = l * w + "px";
                f.css({overflow : "hidden"})
                .children("ul").css({position : "absolute" });
                if (b.width == 0){
                    f.children("ul").children("li").each(function (){
                        if (a(this).width() > e) {
                            e = a(this).height();
                            e2 = a(this).width();
                        }
                    });
                    f.children("ul").children("li").each(function (){
                        a(this).height(e)
                    });
                    f.height(e * b.showItems)
                }
                else {
                    f.width(b.width)
                }
                var d = setInterval(function (){
                    if (b.direction == "left"){
                        moveSlide(f, e2, b)
                        u.css({width : ulw})
                    }else if (b.direction == "Up"){
                        moveUp(f, e, b)
                    }
                    else{
                        moveDown(f, e, b)
                    }
                },
                b.pause);
                if (b.mousePause){
                    f.bind("mouseenter", function (){
                        b.isPaused = true;
                    }).bind("mouseleave", function (){
                        b.isPaused = false;
                    })
                }
            })
        }
    })(jQuery); 
}); 
